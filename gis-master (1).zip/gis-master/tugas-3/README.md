TUGAS 3 PAK BANA
data peta wilayah KAMPUS UMS (1,2, FKG, FKU, KUI) dan jalan alternatif yang menghubungkan semua wilayah kampus. Ditulis dengan menggunakan format geoJSON 
<br>sample online : http://kuliah.l200130083.ga/map/tugas-3/</br>

ditambahkan fitur untuk mempermudah mendapatkan koordinat [lng,lat]<br>
klik di dalam peta untuk mendapatkan koordinat mouse pointer<br>
takan space dan gerakkan mouse kemana saja di dalam peta untuk mendapatkan koordinat yang dilalui mouse pointer<br>
FERRY HERWANTO<br>
L200130083
